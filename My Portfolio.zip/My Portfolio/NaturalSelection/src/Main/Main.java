package Main;

import Functionality.*;
import Window.*;

public class Main {
	public static void main(String[] args) {
		new Simulation(1300,720);
	}
}
