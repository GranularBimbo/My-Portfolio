package Functionality;

public class Button {
	public boolean active;
	public int x,y,w,h;
	
	public Button(int x,int y,int w,int h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}
}
