import pygame
from pygame import *

pygame.mixer.init()

clink = pygame.mixer.Sound("data/audio/clink.ogg")
shweep = pygame.mixer.Sound("data/audio/shield.ogg")
people = pygame.mixer.music.load("data/audio/large_crowd.mp3")



