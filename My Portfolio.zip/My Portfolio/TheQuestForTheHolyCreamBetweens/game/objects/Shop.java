package com.game.objects;

public class Shop {
	public ShopItem[] items;
	
	public Shop(ShopItem[] items) {
		this.items = items;
	}
}
