package com.utility;

public class StatBonus {
	public int amount,stat;
	
	public StatBonus(int amount,int stat) {
		this.amount = amount;
		this.stat = stat;
	}
}
