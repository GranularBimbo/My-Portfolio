import pygame
from pygame.locals import *
pygame.init()

spirits = pygame.mixer.Sound("dode.ogg")
menu = pygame.mixer.music.load("menu_sound.mp3")
laugh = pygame.mixer.Sound("laugh.ogg")
humid_sound = pygame.mixer.Sound("dehumid.ogg")
ambience = pygame.mixer.Sound("ambience.ogg")
off = pygame.mixer.Sound("click_off.ogg")
on = pygame.mixer.Sound("click_on.ogg")
button_click = pygame.mixer.Sound("button_click.ogg")
rec1 = pygame.mixer.Sound("rec1.ogg")
rec2 = pygame.mixer.Sound("rec2.ogg")
rec3 = pygame.mixer.Sound("rec3.ogg")
rec4 = pygame.mixer.Sound("rec4.ogg")
rec5 = pygame.mixer.Sound("rec5.ogg")
snap = pygame.mixer.Sound("snap.ogg")
confused = pygame.mixer.Sound("confused_judah.ogg")
run = pygame.mixer.Sound("running_judah.ogg")
scare = pygame.mixer.Sound("jumpscare.ogg")
yay = pygame.mixer.Sound("yay.ogg")

